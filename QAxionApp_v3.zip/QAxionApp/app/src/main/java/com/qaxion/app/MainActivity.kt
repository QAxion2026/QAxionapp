package com.qaxion.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.KeyEvent
import android.view.View
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.qaxion.app.databinding.ActivityMainBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private var cameraImageUri: Uri? = null
    private var currentUrl: String = ""
    private var obraLabel: String = ""
    private var pendingCameraRequest = false

    companion object {
        private const val PERM_CAMERA = Manifest.permission.CAMERA
        private const val PERM_READ_STORAGE = Manifest.permission.READ_EXTERNAL_STORAGE
        private const val PERM_READ_IMAGES = "android.permission.READ_MEDIA_IMAGES"
    }

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val results = when {
                data?.clipData != null -> Array(data.clipData!!.itemCount) { i -> data.clipData!!.getItemAt(i).uri }
                data?.data != null -> arrayOf(data.data!!)
                cameraImageUri != null -> arrayOf(cameraImageUri!!)
                else -> null
            }
            uploadCallback?.onReceiveValue(results)
        } else {
            uploadCallback?.onReceiveValue(null)
        }
        uploadCallback = null
        cameraImageUri = null
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[PERM_CAMERA] ?: false
        if (pendingCameraRequest) {
            pendingCameraRequest = false
            if (cameraGranted) launchFilePicker(withCamera = true)
            else launchFilePicker(withCamera = false)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        currentUrl = intent.getStringExtra("url") ?: "https://qaxion.com.br"
        obraLabel = intent.getStringExtra("label") ?: "QAxion"

        setupToolbar()
        setupWebView()
        setupButtons()
        loadUrl(currentUrl)
    }

    private fun setupToolbar() {
        binding.tvTitle.text = obraLabel.substringBefore(" — ").trim()
        binding.tvSubtitle.text = obraLabel.substringAfter(" — ", "Quality Management").trim()

        binding.btnBack.setOnClickListener {
            if (binding.webView.canGoBack()) binding.webView.goBack()
            else { finish(); overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right) }
        }
        binding.btnMenu.setOnClickListener { showOptionsMenu() }
        binding.btnSupport.setOnClickListener {
            val email = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:suporte@qaxion.com.br")
                putExtra(Intent.EXTRA_SUBJECT, "Suporte QAxion SGI — $obraLabel")
            }
            try { startActivity(email) }
            catch (e: Exception) { Toast.makeText(this, "suporte@qaxion.com.br", Toast.LENGTH_LONG).show() }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        binding.webView.apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                setSupportMultipleWindows(true)
                javaScriptCanOpenWindowsAutomatically = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                useWideViewPort = true
                loadWithOverviewMode = true
                setSupportZoom(true)
                builtInZoomControls = false
                displayZoomControls = false
                cacheMode = WebSettings.LOAD_DEFAULT
                mediaPlaybackRequiresUserGesture = false
                // Allow PDF/file viewing inside webview when possible
                pluginState = WebSettings.PluginState.ON_DEMAND
                userAgentString = "QAxion-Android/1.0 Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile"
            }
            webViewClient = QAxionWebViewClient()
            webChromeClient = QAxionWebChromeClient()
        }
    }

    private fun setupButtons() {
        binding.btnRetry.setOnClickListener {
            binding.layoutError.visibility = View.GONE
            loadUrl(currentUrl)
        }
    }

    private fun loadUrl(url: String) {
        currentUrl = url
        binding.webView.loadUrl(url)
    }

    // ─── Download Handler ──────────────────────────────────
    private fun handleDownload(url: String, userAgent: String, contentDisposition: String, mimetype: String) {
        // Special case: blob URLs - inject JS to handle
        if (url.startsWith("blob:")) {
            handleBlobUrl(url)
            return
        }

        val fileName = URLUtil.guessFileName(url, contentDisposition, mimetype)
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val resolvedMime = when (ext) {
            "pdf" -> "application/pdf"
            "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            "xls" -> "application/vnd.ms-excel"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "doc" -> "application/msword"
            "csv" -> "text/csv"
            "png", "jpg", "jpeg" -> "image/$ext"
            else -> mimetype.ifBlank { "*/*" }
        }

        try {
            val cookies = CookieManager.getInstance().getCookie(url) ?: ""
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(resolvedMime)
                addRequestHeader("User-Agent", userAgent)
                if (cookies.isNotEmpty()) addRequestHeader("Cookie", cookies)
                setTitle(fileName)
                setDescription("Baixando via QAxion…")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)
            }
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            Toast.makeText(this, "⬇️  Baixando $fileName…", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // Fallback: try opening directly in external browser/app
            try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(i)
            } catch (ex: Exception) {
                Toast.makeText(this, "Não foi possível abrir o arquivo", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun handleBlobUrl(blobUrl: String) {
        val js = """
            (function() {
                var xhr = new XMLHttpRequest();
                xhr.open('GET', '$blobUrl', true);
                xhr.responseType = 'arraybuffer';
                xhr.onload = function() {
                    var bytes = new Uint8Array(xhr.response);
                    var binary = '';
                    for (var i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
                    var base64 = window.btoa(binary);
                    var mime = xhr.getResponseHeader('Content-Type') || 'application/octet-stream';
                    window.QAxionAndroid && window.QAxionAndroid.onBlobReady(base64, mime);
                };
                xhr.send();
            })();
        """.trimIndent()
        binding.webView.evaluateJavascript(js, null)
    }

    private fun showOptionsMenu() {
        val options = arrayOf(
            "🔄  Recarregar página",
            "🏠  Início da obra",
            "📋  Copiar URL",
            "🌐  Abrir no navegador",
            "🏢  Trocar de obra",
            "🚪  Sair / Logout"
        )
        MaterialAlertDialogBuilder(this, R.style.QAxionDialog)
            .setTitle(obraLabel)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> binding.webView.reload()
                    1 -> loadUrl(currentUrl)
                    2 -> copyToClipboard(binding.webView.url ?: currentUrl)
                    3 -> openInBrowser(binding.webView.url ?: currentUrl)
                    4 -> { finish(); overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right) }
                    5 -> doLogout()
                }
            }.show()
    }

    private fun doLogout() {
        MaterialAlertDialogBuilder(this, R.style.QAxionDialog)
            .setTitle("Sair")
            .setMessage("Deseja encerrar sua sessão?")
            .setPositiveButton("Sair") { _, _ ->
                AppData.logout()
                startActivity(Intent(this, LoginActivity::class.java))
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                finishAffinity()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun copyToClipboard(text: String) {
        val cb = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cb.setPrimaryClip(android.content.ClipData.newPlainText("URL", text))
        Toast.makeText(this, "URL copiada!", Toast.LENGTH_SHORT).show()
    }

    private fun openInBrowser(url: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }

    // ─── Permission check for camera ──────────────────────
    private fun hasCameraPermission() = ContextCompat.checkSelfPermission(this, PERM_CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun hasStoragePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, PERM_READ_IMAGES) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, PERM_READ_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestPermissionsForCamera() {
        val permsToRequest = mutableListOf<String>()
        if (!hasCameraPermission()) permsToRequest.add(PERM_CAMERA)
        if (!hasStoragePermission()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) permsToRequest.add(PERM_READ_IMAGES)
            else permsToRequest.add(PERM_READ_STORAGE)
        }
        if (permsToRequest.isEmpty()) {
            launchFilePicker(withCamera = true)
        } else {
            pendingCameraRequest = true
            permissionLauncher.launch(permsToRequest.toTypedArray())
        }
    }

    private fun launchFilePicker(withCamera: Boolean) {
        val contentIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }

        if (withCamera && hasCameraPermission()) {
            val photoFile = createImageFile()
            cameraImageUri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", photoFile)
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri)
            }
            val chooser = Intent(Intent.ACTION_CHOOSER).apply {
                putExtra(Intent.EXTRA_INTENT, contentIntent)
                putExtra(Intent.EXTRA_TITLE, "Selecionar ou fotografar")
                putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(cameraIntent))
            }
            filePickerLauncher.launch(chooser)
        } else {
            filePickerLauncher.launch(contentIntent)
        }
    }

    // ─── WebViewClient ─────────────────────────────────────
    inner class QAxionWebViewClient : WebViewClient() {
        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
            super.onPageStarted(view, url, favicon)
            binding.progressBar.visibility = View.VISIBLE
        }
        override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            binding.progressBar.visibility = View.GONE
            binding.layoutError.visibility = View.GONE
            injectHelpers(view)
        }
        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
            if (request?.isForMainFrame == true) {
                binding.progressBar.visibility = View.GONE
                binding.layoutError.visibility = View.VISIBLE
            }
        }
        @SuppressLint("WebViewClientOnReceivedSslError")
        override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
            handler?.proceed()
        }
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val url = request?.url?.toString() ?: return false
            // Intercept blob: URLs
            if (url.startsWith("blob:")) { handleBlobUrl(url); return true }
            // Intercept file download links
            val downloadExts = listOf(".pdf", ".xls", ".xlsx", ".doc", ".docx", ".csv", ".zip")
            if (downloadExts.any { url.lowercase().contains(it) } && !url.contains("?inline")) {
                handleDownload(url, "QAxion-Android/1.0", "", guessMime(url))
                return true
            }
            return when {
                url.startsWith("tel:") -> { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse(url))); true }
                url.startsWith("mailto:") -> { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse(url))); true }
                else -> false
            }
        }
        private fun guessMime(url: String) = when {
            url.contains(".pdf") -> "application/pdf"
            url.contains(".xlsx") -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            url.contains(".xls") -> "application/vnd.ms-excel"
            url.contains(".docx") -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            else -> "*/*"
        }
        private fun injectHelpers(view: WebView?) {
            val js = """
                (function() {
                  if (document.getElementById('_qax_style')) return;
                  var s = document.createElement('style');
                  s.id = '_qax_style';
                  s.innerHTML = 'body{-webkit-text-size-adjust:100%} input,select,textarea{font-size:16px!important}';
                  document.head && document.head.appendChild(s);
                  document.body && document.body.classList.add('qaxion-mobile-app');
                })();
            """.trimIndent()
            view?.evaluateJavascript(js, null)
        }
    }

    // ─── WebChromeClient ───────────────────────────────────
    inner class QAxionWebChromeClient : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            binding.progressBar.progress = newProgress
            if (newProgress == 100) binding.progressBar.visibility = View.GONE
        }
        override fun onReceivedTitle(view: WebView?, title: String?) {
            if (!title.isNullOrEmpty() && title != "about:blank") binding.tvSubtitle.text = title
        }
        // Camera / microphone permission for WebView
        override fun onPermissionRequest(request: PermissionRequest?) {
            val resources = request?.resources ?: return
            val toGrant = resources.filter { res ->
                when (res) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> hasCameraPermission()
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> true
                    else -> true
                }
            }.toTypedArray()
            if (toGrant.isNotEmpty()) request.grant(toGrant)
            else request.deny()
        }
        override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
        ): Boolean {
            uploadCallback?.onReceiveValue(null)
            uploadCallback = filePathCallback
            requestPermissionsForCamera()
            return true
        }
        override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
            MaterialAlertDialogBuilder(this@MainActivity, R.style.QAxionDialog)
                .setMessage(message).setPositiveButton("OK") { _, _ -> result?.confirm() }
                .setOnCancelListener { result?.cancel() }.show()
            return true
        }
        override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
            MaterialAlertDialogBuilder(this@MainActivity, R.style.QAxionDialog)
                .setMessage(message)
                .setPositiveButton("Confirmar") { _, _ -> result?.confirm() }
                .setNegativeButton("Cancelar") { _, _ -> result?.cancel() }
                .setOnCancelListener { result?.cancel() }.show()
            return true
        }
        // Handle window.open() — used for PDF/QR popups
        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
            val newWebView = WebView(this@MainActivity)
            newWebView.settings.javaScriptEnabled = true
            val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
            transport.webView = newWebView
            resultMsg.sendToTarget()
            // Intercept URL loaded in popup
            newWebView.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val popupUrl = request?.url?.toString() ?: return false
                    // Load in main webview instead of opening new tab
                    binding.webView.loadUrl(popupUrl)
                    return true
                }
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    val popupUrl = url ?: return
                    // Intercept PDF/file URLs from popup
                    val downloadExts = listOf(".pdf", ".xls", ".xlsx", ".doc", ".docx")
                    if (downloadExts.any { popupUrl.lowercase().contains(it) }) {
                        handleDownload(popupUrl, "QAxion-Android/1.0", "", "*/*")
                        return
                    }
                    // For QR code / other content, load in main webview
                    if (!popupUrl.startsWith("about:")) {
                        binding.webView.loadUrl(popupUrl)
                    }
                }
            }
            return true
        }
    }

    private fun createImageFile(): File {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("QAxion_${ts}_", ".jpg", dir)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && binding.webView.canGoBack()) {
            binding.webView.goBack(); return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onPause() { super.onPause(); binding.webView.onPause() }
    override fun onResume() { super.onResume(); binding.webView.onResume() }
    override fun onDestroy() { binding.webView.destroy(); super.onDestroy() }
}
