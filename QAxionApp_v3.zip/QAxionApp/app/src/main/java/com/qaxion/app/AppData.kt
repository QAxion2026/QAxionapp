package com.qaxion.app

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

// ─── Data Models ──────────────────────────────────────────
enum class AccessGroup { ZAIT, INOVA, ADMIN }

data class AppUser(
    val id: String,
    var username: String,
    var password: String,
    var displayName: String,
    var group: AccessGroup,
    val isBuiltIn: Boolean = false  // built-in users can't be deleted
)

data class Obra(
    val id: String,
    var code: String,
    var label: String,
    var url: String,
    var server: String,  // "zait" | "inova"
    var isDashboard: Boolean = false
)

data class UserSession(val user: AppUser)

// ─── App Data Store (in-memory, persisted via SharedPreferences) ──
object AppData {

    private val gson = Gson()

    // Default users
    private val defaultUsers = mutableListOf(
        AppUser("user_zait", "ZAIT", "Zait@2026_02", "ZAIT", AccessGroup.ZAIT, isBuiltIn = true),
        AppUser("user_inova", "INOVATS", "Inova@2026_01", "INOVA TS", AccessGroup.INOVA, isBuiltIn = true),
        AppUser("user_admin", "QAxion_administration_2026", "QAxion_administration_n82921657", "Administrador", AccessGroup.ADMIN, isBuiltIn = true)
    )

    // Default obras
    private val defaultObras = mutableListOf(
        // ZAIT — Dashboard
        Obra("zait_dash", "Dashboard", "Dashboard Central - Todas as Obras",
            "https://zait.qaxion.com.br/dashboard_central.php", "zait", isDashboard = true),
        // ZAIT — Obras
        Obra("z2402", "Z.24.02", "SHOPPING CARNOT", "https://zait.qaxion.com.br/Z.24.02/index.php", "zait"),
        Obra("z2502", "Z.25.02", "VL SERENA", "https://zait.qaxion.com.br/Z.25.02/index.php", "zait"),
        Obra("z2503", "Z.25.03", "CASA PANORAMA", "https://zait.qaxion.com.br/Z.25.03/index.php", "zait"),
        Obra("z2504", "Z.25.04", "CASA MARQUISE", "https://zait.qaxion.com.br/Z.25.04/index.php", "zait"),
        Obra("z2505", "Z.25.05", "VL BRISAS", "https://zait.qaxion.com.br/Z.25.05/index.php", "zait"),
        Obra("z2506", "Z.25.06", "CASA ROSENBAUM", "https://zait.qaxion.com.br/Z.25.06/index.php", "zait"),
        Obra("z2507", "Z.25.07", "CASA M&A", "https://zait.qaxion.com.br/Z.25.07/index.php", "zait"),
        Obra("z2508", "Z.25.08", "IBÁ", "https://zait.qaxion.com.br/Z.25.08/index.php", "zait"),
        Obra("z2604", "Z.26.04", "CASA R&L", "https://zait.qaxion.com.br/Z.26.04/index.php", "zait"),
        // INOVA — Dashboard
        Obra("inova_dash", "Dashboard", "Dashboard Central - Todas as Obras",
            "https://inova.qaxion.com.br/dashboard_central.php", "inova", isDashboard = true),
        // INOVA — Obras
        Obra("ts221", "TS221", "iNOVA TS OBRA 221 — Nestlé Projeto — Kaldi 2 / Fastback",
            "https://inova.qaxion.com.br/TS221/index.php", "inova"),
        Obra("ts227", "TS227", "iNOVA TS OBRA 227 — Nestlé VV — Reforma Telhado 25G + STRIP",
            "https://inova.qaxion.com.br/TS227/index.php", "inova"),
    )

    var users: MutableList<AppUser> = defaultUsers.toMutableList()
    var obras: MutableList<Obra> = defaultObras.toMutableList()
    var currentSession: UserSession? = null

    fun load(prefs: android.content.SharedPreferences) {
        val usersJson = prefs.getString("users", null)
        val obrasJson = prefs.getString("obras", null)
        if (usersJson != null) {
            val type = object : TypeToken<MutableList<AppUser>>() {}.type
            users = gson.fromJson(usersJson, type) ?: defaultUsers.toMutableList()
        }
        if (obrasJson != null) {
            val type = object : TypeToken<MutableList<Obra>>() {}.type
            obras = gson.fromJson(obrasJson, type) ?: defaultObras.toMutableList()
        }
    }

    fun save(prefs: android.content.SharedPreferences) {
        prefs.edit()
            .putString("users", gson.toJson(users))
            .putString("obras", gson.toJson(obras))
            .apply()
    }

    fun login(username: String, password: String): AppUser? {
        val user = users.find { it.username.trim() == username.trim() && it.password == password.trim() }
        currentSession = user?.let { UserSession(it) }
        return user
    }

    fun logout() { currentSession = null }

    fun getObrasForGroup(group: AccessGroup, server: String): List<Obra> {
        return obras.filter { it.server == server }
    }
}
