package com.qaxion.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.tabs.TabLayout
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.qaxion.app.databinding.ActivityAdminBinding
import java.util.UUID

class AdminActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdminBinding
    private lateinit var userAdapter: UserAdminAdapter
    private lateinit var obraAdapter: ObraAdminAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupTabs()
        setupUserList()
        setupObraList()
        setupAddButtons()
    }

    private fun setupToolbar() {
        binding.btnBack.setOnClickListener { finish(); overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right) }
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                when (tab.position) {
                    0 -> { binding.layoutUsers.visibility = View.VISIBLE; binding.layoutObras.visibility = View.GONE }
                    1 -> { binding.layoutUsers.visibility = View.GONE; binding.layoutObras.visibility = View.VISIBLE }
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    private fun setupUserList() {
        userAdapter = UserAdminAdapter(
            onEdit = { user -> showEditUserDialog(user) },
            onDelete = { user -> confirmDeleteUser(user) }
        )
        binding.rvUsers.apply {
            layoutManager = LinearLayoutManager(this@AdminActivity)
            adapter = userAdapter
        }
        refreshUsers()
    }

    private fun setupObraList() {
        obraAdapter = ObraAdminAdapter(
            onEdit = { obra -> showEditObraDialog(obra) },
            onDelete = { obra -> confirmDeleteObra(obra) }
        )
        binding.rvObras.apply {
            layoutManager = LinearLayoutManager(this@AdminActivity)
            adapter = obraAdapter
        }
        refreshObras()
    }

    private fun setupAddButtons() {
        binding.btnAddUser.setOnClickListener { showAddUserDialog() }
        binding.btnAddObra.setOnClickListener { showAddObraDialog() }
    }

    private fun refreshUsers() { userAdapter.submitList(AppData.users.toList()) }
    private fun refreshObras() { obraAdapter.submitList(AppData.obras.toList()) }

    private fun saveAndRefreshUsers() {
        val prefs = getSharedPreferences("qaxion_data", MODE_PRIVATE)
        AppData.save(prefs)
        refreshUsers()
    }

    private fun saveAndRefreshObras() {
        val prefs = getSharedPreferences("qaxion_data", MODE_PRIVATE)
        AppData.save(prefs)
        refreshObras()
    }

    // ─── User Dialogs ──────────────────────────────────────
    private fun showAddUserDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_user_form, null)
        val etUser = view.findViewById<TextInputEditText>(R.id.etFormUser)
        val etPass = view.findViewById<TextInputEditText>(R.id.etFormPassword)
        val etName = view.findViewById<TextInputEditText>(R.id.etFormName)
        val spinnerGroup = view.findViewById<android.widget.Spinner>(R.id.spinnerGroup)

        val groups = arrayOf("ZAIT", "INOVA TS", "Administrador")
        spinnerGroup.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, groups)

        MaterialAlertDialogBuilder(this, R.style.QAxionDialog)
            .setTitle("Novo Usuário")
            .setView(view)
            .setPositiveButton("Criar") { _, _ ->
                val username = etUser.text?.toString()?.trim() ?: ""
                val password = etPass.text?.toString()?.trim() ?: ""
                val name = etName.text?.toString()?.trim() ?: ""
                if (username.isBlank() || password.isBlank() || name.isBlank()) return@setPositiveButton
                val group = when (spinnerGroup.selectedItemPosition) {
                    1 -> AccessGroup.INOVA
                    2 -> AccessGroup.ADMIN
                    else -> AccessGroup.ZAIT
                }
                AppData.users.add(AppUser(UUID.randomUUID().toString(), username, password, name, group))
                saveAndRefreshUsers()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showEditUserDialog(user: AppUser) {
        val view = layoutInflater.inflate(R.layout.dialog_user_form, null)
        val etUser = view.findViewById<TextInputEditText>(R.id.etFormUser)
        val etPass = view.findViewById<TextInputEditText>(R.id.etFormPassword)
        val etName = view.findViewById<TextInputEditText>(R.id.etFormName)
        val spinnerGroup = view.findViewById<android.widget.Spinner>(R.id.spinnerGroup)

        etUser.setText(user.username)
        etPass.setText(user.password)
        etName.setText(user.displayName)

        val groups = arrayOf("ZAIT", "INOVA TS", "Administrador")
        spinnerGroup.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, groups)
        spinnerGroup.setSelection(when (user.group) { AccessGroup.INOVA -> 1; AccessGroup.ADMIN -> 2; else -> 0 })

        MaterialAlertDialogBuilder(this, R.style.QAxionDialog)
            .setTitle("Editar Usuário")
            .setView(view)
            .setPositiveButton("Salvar") { _, _ ->
                val idx = AppData.users.indexOfFirst { it.id == user.id }
                if (idx >= 0) {
                    AppData.users[idx].apply {
                        username = etUser.text?.toString()?.trim() ?: username
                        password = etPass.text?.toString()?.trim().takeIf { !it.isNullOrBlank() } ?: password
                        displayName = etName.text?.toString()?.trim() ?: displayName
                        group = when (spinnerGroup.selectedItemPosition) { 1 -> AccessGroup.INOVA; 2 -> AccessGroup.ADMIN; else -> AccessGroup.ZAIT }
                    }
                    saveAndRefreshUsers()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmDeleteUser(user: AppUser) {
        if (user.isBuiltIn) {
            MaterialAlertDialogBuilder(this, R.style.QAxionDialog)
                .setTitle("Não permitido")
                .setMessage("Usuários padrão do sistema não podem ser excluídos, apenas editados.")
                .setPositiveButton("OK", null).show()
            return
        }
        MaterialAlertDialogBuilder(this, R.style.QAxionDialog)
            .setTitle("Excluir Usuário")
            .setMessage("Excluir \"${user.displayName}\"? Esta ação não pode ser desfeita.")
            .setPositiveButton("Excluir") { _, _ ->
                AppData.users.removeAll { it.id == user.id }
                saveAndRefreshUsers()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    // ─── Obra Dialogs ──────────────────────────────────────
    private fun showAddObraDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_obra_form, null)
        val etCode = view.findViewById<TextInputEditText>(R.id.etObraCode)
        val etLabel = view.findViewById<TextInputEditText>(R.id.etObraLabel)
        val etUrl = view.findViewById<TextInputEditText>(R.id.etObraUrl)
        val spinnerServer = view.findViewById<android.widget.Spinner>(R.id.spinnerServer)

        val servers = arrayOf("ZAIT", "INOVA TS")
        spinnerServer.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, servers)

        MaterialAlertDialogBuilder(this, R.style.QAxionDialog)
            .setTitle("Nova Obra")
            .setView(view)
            .setPositiveButton("Adicionar") { _, _ ->
                val code = etCode.text?.toString()?.trim() ?: ""
                val label = etLabel.text?.toString()?.trim() ?: ""
                val url = etUrl.text?.toString()?.trim() ?: ""
                if (code.isBlank() || label.isBlank() || url.isBlank()) return@setPositiveButton
                val server = if (spinnerServer.selectedItemPosition == 0) "zait" else "inova"
                val finalUrl = if (url.startsWith("http")) url else "https://$url"
                AppData.obras.add(Obra(UUID.randomUUID().toString(), code, label, finalUrl, server))
                saveAndRefreshObras()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun showEditObraDialog(obra: Obra) {
        val view = layoutInflater.inflate(R.layout.dialog_obra_form, null)
        val etCode = view.findViewById<TextInputEditText>(R.id.etObraCode)
        val etLabel = view.findViewById<TextInputEditText>(R.id.etObraLabel)
        val etUrl = view.findViewById<TextInputEditText>(R.id.etObraUrl)
        val spinnerServer = view.findViewById<android.widget.Spinner>(R.id.spinnerServer)

        etCode.setText(obra.code)
        etLabel.setText(obra.label)
        etUrl.setText(obra.url)

        val servers = arrayOf("ZAIT", "INOVA TS")
        spinnerServer.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, servers)
        spinnerServer.setSelection(if (obra.server == "inova") 1 else 0)

        MaterialAlertDialogBuilder(this, R.style.QAxionDialog)
            .setTitle("Editar Obra")
            .setView(view)
            .setPositiveButton("Salvar") { _, _ ->
                val idx = AppData.obras.indexOfFirst { it.id == obra.id }
                if (idx >= 0) {
                    AppData.obras[idx].apply {
                        code = etCode.text?.toString()?.trim() ?: code
                        label = etLabel.text?.toString()?.trim() ?: label
                        url = etUrl.text?.toString()?.trim() ?: url
                        server = if (spinnerServer.selectedItemPosition == 1) "inova" else "zait"
                    }
                    saveAndRefreshObras()
                }
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun confirmDeleteObra(obra: Obra) {
        MaterialAlertDialogBuilder(this, R.style.QAxionDialog)
            .setTitle("Excluir Obra")
            .setMessage("Excluir \"${obra.code} — ${obra.label}\"?")
            .setPositiveButton("Excluir") { _, _ ->
                AppData.obras.removeAll { it.id == obra.id }
                saveAndRefreshObras()
            }
            .setNegativeButton("Cancelar", null).show()
    }
}

// ─── User Adapter ──────────────────────────────────────────
class UserAdminAdapter(
    private val onEdit: (AppUser) -> Unit,
    private val onDelete: (AppUser) -> Unit
) : RecyclerView.Adapter<UserAdminAdapter.VH>() {

    private var items: List<AppUser> = emptyList()
    fun submitList(list: List<AppUser>) { items = list; notifyDataSetChanged() }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvAdminItemTitle)
        val tvSub: TextView = view.findViewById(R.id.tvAdminItemSub)
        val btnEdit: MaterialButton = view.findViewById(R.id.btnAdminEdit)
        val btnDelete: MaterialButton = view.findViewById(R.id.btnAdminDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_admin_row, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val u = items[position]
        holder.tvName.text = "${u.displayName}  (${u.username})"
        val groupLabel = when (u.group) { AccessGroup.ZAIT -> "ZAIT"; AccessGroup.INOVA -> "INOVA TS"; AccessGroup.ADMIN -> "Administrador" }
        holder.tvSub.text = "Grupo: $groupLabel${if (u.isBuiltIn) " · padrão" else ""}"
        holder.btnEdit.setOnClickListener { onEdit(u) }
        holder.btnDelete.setOnClickListener { onDelete(u) }
        holder.btnDelete.isEnabled = !u.isBuiltIn
        holder.btnDelete.alpha = if (u.isBuiltIn) 0.4f else 1f
    }

    override fun getItemCount() = items.size
}

// ─── Obra Adapter ──────────────────────────────────────────
class ObraAdminAdapter(
    private val onEdit: (Obra) -> Unit,
    private val onDelete: (Obra) -> Unit
) : RecyclerView.Adapter<ObraAdminAdapter.VH>() {

    private var items: List<Obra> = emptyList()
    fun submitList(list: List<Obra>) { items = list; notifyDataSetChanged() }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvAdminItemTitle)
        val tvSub: TextView = view.findViewById(R.id.tvAdminItemSub)
        val btnEdit: MaterialButton = view.findViewById(R.id.btnAdminEdit)
        val btnDelete: MaterialButton = view.findViewById(R.id.btnAdminDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_admin_row, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val o = items[position]
        holder.tvName.text = "${o.code} — ${o.label}"
        holder.tvSub.text = "${o.server.uppercase()} · ${o.url}"
        holder.btnEdit.setOnClickListener { onEdit(o) }
        holder.btnDelete.setOnClickListener { onDelete(o) }
    }

    override fun getItemCount() = items.size
}
