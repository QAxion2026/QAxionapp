package com.qaxion.app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.qaxion.app.databinding.ActivitySelectorBinding

class SelectorActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySelectorBinding
    private lateinit var obraAdapter: ObraAdapter
    private var selectedServer: String = "zait"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val session = AppData.currentSession ?: run { goToLogin(); return }

        selectedServer = when (session.user.group) {
            AccessGroup.INOVA -> "inova"
            else -> "zait"
        }

        setupHeader(session)
        setupServerChips(session)
        setupObraList()
        updateObraList()
        setupLogout()
    }

    private fun setupHeader(session: UserSession) {
        binding.tvUserName.text = "Olá, ${session.user.displayName}"

        // Show admin button only for ADMIN
        if (session.user.group == AccessGroup.ADMIN) {
            binding.btnAdmin.visibility = View.VISIBLE
            binding.btnAdmin.setOnClickListener {
                startActivity(Intent(this, AdminActivity::class.java))
            }
        } else {
            binding.btnAdmin.visibility = View.GONE
        }
    }

    private fun setupServerChips(session: UserSession) {
        if (session.user.group != AccessGroup.ADMIN) {
            binding.chipGroupServers.visibility = View.GONE
            return
        }
        binding.chipGroupServers.visibility = View.VISIBLE
        listOf("zait" to "ZAIT", "inova" to "INOVA TS").forEach { (key, name) ->
            val chip = Chip(this).apply {
                text = name; tag = key; isCheckable = true
                isChecked = key == selectedServer
                setChipBackgroundColorResource(if (key == selectedServer) R.color.primary else R.color.chip_default)
                setTextColor(if (key == selectedServer) getColor(R.color.white) else getColor(R.color.text_secondary))
            }
            chip.setOnClickListener { selectedServer = key; updateChipStates(); updateObraList() }
            binding.chipGroupServers.addView(chip)
        }
    }

    private fun updateChipStates() {
        for (i in 0 until binding.chipGroupServers.childCount) {
            val chip = binding.chipGroupServers.getChildAt(i) as? Chip ?: continue
            val isSelected = chip.tag == selectedServer
            chip.isChecked = isSelected
            chip.setChipBackgroundColorResource(if (isSelected) R.color.primary else R.color.chip_default)
            chip.setTextColor(if (isSelected) getColor(R.color.white) else getColor(R.color.text_secondary))
        }
    }

    private fun setupObraList() {
        obraAdapter = ObraAdapter { obra -> openObra(obra) }
        binding.rvObras.apply {
            layoutManager = GridLayoutManager(this@SelectorActivity, 2)
            adapter = obraAdapter
        }
    }

    private fun updateObraList() {
        val filtered = AppData.obras.filter { it.server == selectedServer }
        obraAdapter.submitList(filtered)
        binding.tvEmptyState.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onResume() {
        super.onResume()
        // Refresh list after returning from admin panel
        updateObraList()
    }

    private fun setupLogout() {
        binding.btnLogout.setOnClickListener { confirmLogout() }
    }

    private fun confirmLogout() {
        MaterialAlertDialogBuilder(this, R.style.QAxionDialog)
            .setTitle("Sair")
            .setMessage("Deseja encerrar sua sessão?")
            .setPositiveButton("Sair") { _, _ -> goToLogin() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun goToLogin() {
        AppData.logout()
        startActivity(Intent(this, LoginActivity::class.java))
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
        finishAffinity()
    }

    private fun openObra(obra: Obra) {
        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra("url", obra.url)
            putExtra("label", "${obra.code} — ${obra.label}")
        }
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        confirmLogout()
    }
}

// ─── Adapter ──────────────────────────────────────────────
class ObraAdapter(private val onClick: (Obra) -> Unit) : RecyclerView.Adapter<ObraAdapter.ViewHolder>() {

    private var items: List<Obra> = emptyList()

    fun submitList(list: List<Obra>) { items = list; notifyDataSetChanged() }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val card: MaterialCardView = view.findViewById(R.id.cardObra)
        val tvCode: TextView = view.findViewById(R.id.tvObraCode)
        val tvLabel: TextView = view.findViewById(R.id.tvObraLabel)
        val tvDashBadge: TextView = view.findViewById(R.id.tvDashBadge)
        val btnAccess: MaterialButton = view.findViewById(R.id.btnAccess)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_obra, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val obra = items[position]
        holder.tvCode.text = obra.code
        holder.tvLabel.text = obra.label
        holder.tvDashBadge.visibility = if (obra.isDashboard) View.VISIBLE else View.GONE
        if (obra.isDashboard) {
            holder.card.setCardBackgroundColor(holder.itemView.context.getColor(R.color.dashboard_bg))
            holder.btnAccess.text = "Abrir Dashboard"
        } else {
            holder.card.setCardBackgroundColor(holder.itemView.context.getColor(R.color.surface))
            holder.btnAccess.text = "Acessar"
        }
        holder.btnAccess.setOnClickListener { onClick(obra) }
        holder.itemView.setOnClickListener { onClick(obra) }
    }

    override fun getItemCount() = items.size
}
