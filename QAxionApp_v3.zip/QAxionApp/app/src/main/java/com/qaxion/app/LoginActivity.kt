package com.qaxion.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import com.qaxion.app.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load persisted data
        val prefs = getSharedPreferences("qaxion_data", MODE_PRIVATE)
        AppData.load(prefs)

        binding.etPassword.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { attemptLogin(); true } else false
        }
        binding.btnLogin.setOnClickListener { attemptLogin() }
    }

    private fun attemptLogin() {
        val user = binding.etUser.text?.toString()?.trim() ?: ""
        val password = binding.etPassword.text?.toString() ?: ""

        binding.tilUser.error = null
        binding.tilPassword.error = null

        if (user.isEmpty()) { binding.tilUser.error = "Digite seu usuário"; binding.etUser.requestFocus(); return }
        if (password.isEmpty()) { binding.tilPassword.error = "Digite sua senha"; binding.etPassword.requestFocus(); return }

        binding.btnLogin.isEnabled = false
        binding.progressLogin.visibility = View.VISIBLE
        binding.btnLogin.text = "Entrando…"

        Handler(Looper.getMainLooper()).postDelayed({
            val loggedUser = AppData.login(user, password)
            if (loggedUser != null) {
                binding.layoutError.visibility = View.GONE
                startActivity(Intent(this, SelectorActivity::class.java))
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                finish()
            } else {
                binding.progressLogin.visibility = View.GONE
                binding.btnLogin.isEnabled = true
                binding.btnLogin.text = "Entrar"
                binding.layoutError.visibility = View.VISIBLE
                binding.etPassword.text?.clear()
                binding.etPassword.requestFocus()
                val shake = android.view.animation.AnimationUtils.loadAnimation(this, R.anim.shake)
                binding.cardLogin.startAnimation(shake)
            }
        }, 700)
    }
}
