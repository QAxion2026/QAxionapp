# QAxion SGI — App Android v1.1.0

App Android nativo para o **QAxion Quality Management System**.

---

## 🔐 Credenciais de Acesso

| Usuário | Senha | Acesso |
|---|---|---|
| `INOVATS` | `Inova@2026_01` | Obras INOVA TS |
| `ZAIT` | `Zait@2026_02` | Obras ZAIT |
| `QAxion_administration_2026` | `QAxion_administration_n82921657` | **Todas as obras** |

---

## 📱 Fluxo do App

1. **Splash** → Logo animado (2.8s)
2. **Login** → Autenticação por credenciais
3. **Seletor de Obras** → Filtrado pelo grupo do usuário logado
4. **WebView** → Acesso ao sistema da obra selecionada

---

## ✨ Recursos

- Login com 3 perfis (ZAIT / INOVA TS / Admin)
- Admin vê obras de ambos os servidores
- PDF e Excel: download automático e abertura no app nativo
- Balão de suporte (📧 suporte@qaxion.com.br)
- Menu de 3 pontos com opções de navegação e logout
- Sem pull-to-refresh (removido conforme solicitado)
- Logo oficial da empresa integrada

---

## ➕ Adicionar Obras

No `SelectorActivity.kt`, na lista `allObras`:

```kotlin
Obra("Z.25.06", "Obra Z.25.06", "https://zait.qaxion.com.br/Z.25.06/index.php", "zait"),
Obra("I.25.02", "Nome da Obra", "https://inova.qaxion.com.br/obra222.html", "inova"),
```

---

## ▶️ Como compilar

1. Android Studio → `File → Open → QAxionApp`
2. Aguardar Gradle sync
3. Run → ▶️

**Requisitos:** Android Studio Hedgehog+, SDK 34, Kotlin 1.9+, Android 7.0+ (API 24)
